package com.gmm.wanandroiddemo.base

interface IBasePresenter {
}