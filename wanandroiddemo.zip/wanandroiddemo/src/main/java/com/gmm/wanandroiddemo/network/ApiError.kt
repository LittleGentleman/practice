package com.gmm.wanandroiddemo.network

data class ApiError(var status:Int, var message:String)