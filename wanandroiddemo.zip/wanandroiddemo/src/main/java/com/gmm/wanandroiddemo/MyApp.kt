package com.gmm.wanandroiddemo

import android.app.Application
import com.gmm.wanandroiddemo.network.HttpClient

class MyApp :Application() {

    override fun onCreate() {
        super.onCreate()

        HttpClient.instance.createRetrofit()

    }
}